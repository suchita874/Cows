import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-eggcake',
  templateUrl: './eggcake.component.html',
  styleUrls: ['./eggcake.component.css']
})
export class EggcakeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
