import { Component, OnInit } from '@angular/core';
import { CartService } from '../cart.service';
// import { Buffer } from 'buffer';


@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {
  //   public base64Flag = 'data:image/jpeg;base64,';

  imageSrc = [{image:"https://cdn.shopify.com/s/files/1/1060/3816/products/lucious-butter-scotch-cake_large.jpg?v=1643338807",name:"Vanila Flavour",price:300},
{image:"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRRvCRsR1Pn7jG-p8-bsTLRKBPLRnUak2w3uA&usqp=CAU",name:"Cream Cake",price:430},
{image:"https://images.unsplash.com/photo-1578985545062-69928b1d9587?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxleHBsb3JlLWZlZWR8NHx8fGVufDB8fHx8&w=1000&q=80",name:"Black Forest Cake",price:500},
{image:"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSlsosbtav34bXi3w0Nuqimh-UKGBk-nvOQyQ&usqp=CAU",name:"Chocolate Cake",price:500},
{image:"https://images.unsplash.com/photo-1588195538326-c5b1e9f80a1b?ixlib=rb-1.2.1&w=1080&fit=max&q=80&fm=jpg&crop=entropy&cs=tinysrgb",name:"Vanila Cake",price:450},
{image:"https://imagesvc.meredithcorp.io/v3/mm/image?url=https%3A%2F%2Fimg1.cookinglight.timeinc.net%2Fsites%2Fdefault%2Ffiles%2Fstyles%2Fmedium_2x%2Fpublic%2F1542062283%2Fchocolate-and-cream-layer-cake-1812-cover.jpg%3Fitok%3DrEWL7AIN",name:"Strawberry Cake",price:600},
{image:"https://content.jdmagicbox.com/comp/vijayawada/x8/0866px866.x866.211026094808.m2x8/catalogue/-lgxd7f7626.jpg?clr=",name:"Chocolate Cake",price:250},
{image:"https://assets.winni.in/c_limit,dpr_2,fl_progressive,q_80,w_220/73538_choco-strawberry-cake.jpeg",name:"Straberry Cake",price:900},
{image:"https://www.cakengifts.in/product-images/CGC1126-round-pineapple-cake-n-cherry/regular/round-pineapple-cake-n-cherry.jpg",name:"Pineapple Cale",price:800},
{image:"https://images.pexels.com/photos/1721932/pexels-photo-1721932.jpeg?auto=compress&cs=tinysrgb&w=600",name:"Vanila Cake",price:750}]

  public totalItem : number = 0

  constructor( private cart : CartService) { }  //inject cart service

  ngOnInit(): void {
    this.cart.getProducts().subscribe(res =>{
      this.totalItem = res.length;  //length the property which we get on response
    })

   
  }
  addtoCart(item : any){     //// item which is coming from .html file it consist of product item 
    this.cart.addtoCart(item);
  }

}





    // // this.auth.getProduct()
    // // .subscribe(res=> {
 

    // //   this.productList = res;
    // //   this.List = Object.keys(this.productList)[1];
    // //   this.productList = this.productList[this.List];
    // //   console.log(this.productList);
    // //   this.productList.forEach((item : any)=>{
    // //     console.log(item.image);
    // //     this.string64A = Buffer.from(item.image).toString('base64');
    // //     console.log(this.string64A);
    // //     this.img = this.base64Flag + this.string64A;
    // //   })
    // // })
