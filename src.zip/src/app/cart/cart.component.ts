import { Component, OnInit } from '@angular/core';
import { CartService } from '../cart.service';


@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {

  public cartItem : any = [];
  public total : number = 0;

  constructor(private cart : CartService) { }   

  ngOnInit(): void {
    this.cart.getProducts().subscribe(res => {
      this.cartItem = res;
      console.log(this.cartItem);
      // this.total = this.cart.getTotalPrice();
    })
  }

  removeItem(item : any){
    this.cart.removeCartItem(item);
  }

  emptyCart(){
    this.cart.removeAllCartItem();
  }
}
